module.exports = { PENDING: 0,
    LATE: 1,
    DONE: 2,
    ALL: 3 }